package process

import (
	"fmt"
	"strings"
)

type Iprocess interface {
	Process(req string) (string, error)
}

var morsemap = map[string]string{
	"A": ".-",
	"B": "-...",
	"C": "-.-.",
	"D": "-..",
	"E": ".",
	"F": "..-.",
	"G": "--.",
	"H": "....",
	"I": "..",
	"J": ".---",
	"K": "-.-",
	"L": ".-..",
	"M": "--",
	"N": "-.",
	"O": "---",
	"P": ".--.",
	"Q": "--.-",
	"R": ".-.",
	"S": "...",
	"T": "-",
	"U": "..-",
	"V": "...-",
	"W": ".--",
	"X": "-..-",
	"Y": "-.--",
	"Z": "--..",
}

var characterMap = map[string]string{}

func init() {
	for key, value := range morsemap {
		characterMap[value] = key
	}
}

func translate(textoatraducir string, formatoOrigen string, formatoDestino string) (string, error) {
	var response string

	if formatoDestino == "BINARY" {

		response = binary(textoatraducir)
	} else if formatoDestino == "MORSE" {
		response = morse(textoatraducir)
	} else {
		response = ""
	}
	return response, nil
}

func binary(s string) string {
	res := ""
	for _, c := range s {
		res = fmt.Sprintf("%s%.8b", res, c)
	}
	return res
}

func morse(s string) string {
	message := "Hello, World!"
	delimiter := " "
	fmt.Println(encodeMessage(message, delimiter))
	return encodeMessage(message, delimiter)
}

func encodeMessage(message, letterSplitter string) string {
	var output string
	message = strings.ToUpper(message)
	words := strings.Split(message, " ")
	for _, word := range words {
		word := encodeWord(word, letterSplitter)
		if word != "" {
			output += word
		}
	}
	return output
}

func encodeWord(word, letterSplitter string) string {
	var morse string
	for i := 0; i < len(word); i++ {
		code := morsemap[word[i:i+1]]
		if code != "" {
			morse += code + letterSplitter
		}
	}
	return morse
}
