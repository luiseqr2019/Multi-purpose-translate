package main

import (
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
)

func main() {

	/** creating go rutine to health **/
	go func() {
		logger.Info("transport", "http", "address", port, "msg", "listening")
		//Se inician los scheduled task
		errs <- http.ListenAndServe(":"+port, mux)
	}()

	go func() {
		c := make(chan os.Signal)
		signal.Notify(c, syscall.SIGINT)
		signal.Notify(c, syscall.SIGTERM)
		errs <- fmt.Errorf("%s", <-c)

	}()
	logger.Info("terminated", <-errs)
}
